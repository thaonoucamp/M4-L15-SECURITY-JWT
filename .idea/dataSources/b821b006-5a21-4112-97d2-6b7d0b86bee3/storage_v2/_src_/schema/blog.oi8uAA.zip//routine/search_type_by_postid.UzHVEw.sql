create
    definer = root@localhost procedure search_type_by_postid(IN postId int)
begin
	SELECT * FROM blog.post p
	join blog.post_type pt on p.id=pt.postId
    join blog.type t on t.id=pt.typeid
    where p.id=postId;
end;


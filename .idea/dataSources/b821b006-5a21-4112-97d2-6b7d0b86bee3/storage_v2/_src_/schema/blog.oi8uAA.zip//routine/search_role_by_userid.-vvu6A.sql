create
    definer = root@localhost procedure search_role_by_userid(IN userid int)
begin
	SELECT * FROM blog.user u
	join blog.user_role ur on u.id=ur.userId
    join blog.role r on r.id=ur.roleId
    where u.id=userId;
end;


create
    definer = root@localhost procedure sort_post(IN type varchar(50))
begin
	if(type like 'datetime') then
	SELECT * FROM blog.post	order by post.datetime desc;
    elseif(type like 'view') then
    SELECT * FROM blog.post	order by post.view desc;
    end if;
end;


create
    definer = root@localhost procedure search_post_by_type(IN typeid int)
begin
	
	SELECT * FROM blog.post p
	join blog.post_type pt on p.id=pt.postId
    join blog.type t on t.id=pt.typeid
    where t.id like typeid;
    
end;


create view usercmt as
select `u`.`id`       AS `id`,
       `u`.`username` AS `username`,
       `u`.`password` AS `password`,
       `u`.`email`    AS `email`,
       `u`.`address`  AS `address`,
       `u`.`avatar`   AS `avatar`,
       `c`.`postId`   AS `postId`
from (`blog`.`comment` `c`
         join `blog`.`user` `u` on ((`c`.`userId` = `u`.`id`)));

